"""Built-in tools for bidirectional agents."""

from .stop_conversation import stop_conversation

__all__ = ["stop_conversation"]
